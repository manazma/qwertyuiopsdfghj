<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitor Swap Orion</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="../css/admin_style.css?v=<?php echo time(); ?>">
    
    <meta http-equiv="refresh" content="30">
</head>
<body>

<div class="container">
    
    <div class="header-section">
        <h2>
            <span style="color: #0ea5e9;">📊</span> Laporan Trafik Swap
        </h2>
        <div>
            <a href="admin_burn.php" class="refresh-btn" style="margin-right:10px;">burn Logs</a>
            <a href="admin_monitor.php" class="refresh-btn">🔄 Refresh Data</a>
        </div>
    </div>

    <div class="card">
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th width="15%">Waktu</th>
                        <th width="15%">Wallet</th>
                        <th width="20%">Swap Dari</th>
                        <th width="20%">Swap Ke</th>
                        <th width="10%">Status</th>
                        <th width="20%">Tx Hash</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // --- KONFIGURASI DATABASE ---
                    $host = 'localhost';
                    $db   = 'orionzer_orion';
                    $user = 'orionzer_manaz';
                    $pass = 'Alif@2003';

                    try {
                        $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
                        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                        // Ambil 50 data terbaru
                        $stmt = $pdo->query("SELECT * FROM swap_logs ORDER BY created_at DESC LIMIT 50");
                        
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            // Format Tampilan Data
                            $hashShort = substr($row['tx_hash'], 0, 6) . '...' . substr($row['tx_hash'], -4);
                            $walletShort = substr($row['user_wallet'], 0, 6) . '...' . substr($row['user_wallet'], -4);
                            
                            // Format Waktu agar lebih rapi
                            $timeObj = new DateTime($row['created_at']);
                            $dateFormatted = $timeObj->format('d M, H:i');
                            
                            echo "<tr>";
                            
                            // Kolom Waktu
                            echo "<td><span class='font-mono'>" . $dateFormatted . "</span></td>";
                            
                            // Kolom Wallet (dengan tooltip)
                            echo "<td title='".$row['user_wallet']."'><span class='font-mono' style='color:#64748b'>" . $walletShort . "</span></td>";
                            
                            // Kolom Swap In
                            echo "<td><span class='amount'>" . number_format($row['amount_in'], 2) . "</span> <span class='text-muted'>" . $row['token_from'] . "</span></td>";
                            
                            // Kolom Swap Out
                            echo "<td><span class='amount'>" . number_format($row['amount_out'], 2) . "</span> <span class='text-muted'>" . $row['token_to'] . "</span></td>";
                            
                            // Kolom Status
                            echo "<td><span class='badge badge-success'>Success</span></td>";
                            
                            // Kolom Hash (Link)
                            echo "<td><a class='hash-link' href='https://explorer.paxinet.io/tx/" . $row['tx_hash'] . "' target='_blank'>$hashShort ↗</a></td>";
                            
                            echo "</tr>";
                        }
                    } catch (PDOException $e) {
                        echo "<tr><td colspan='6' style='padding: 2rem; color: #ef4444; text-align:center; font-weight:bold;'>Error Database: " . $e->getMessage() . "</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div style="text-align: center; margin-top: 20px; color: #94a3b8; font-size: 12px;">
        &copy; Orion Swap Monitor System
    </div>

</div>

</body>
</html>