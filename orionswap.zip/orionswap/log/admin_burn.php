<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Burn History | Orion Zera</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/admin_style.css?v=<?php echo time(); ?>">
    <meta http-equiv="refresh" content="30">
</head>
<body>

<div class="container">
    <div class="header-section">
        <h2>🔥 Incinerator History</h2>
        <div>
            <a href="admin_monitor.php" class="refresh-btn" style="margin-right:10px;">Swap Logs</a>
            <a href="admin_burn.php" class="refresh-btn">🔄 Refresh</a>
        </div>
    </div>

    <div class="card">
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th width="15%">Time</th>
                        <th width="15%">Wallet</th>
                        <th width="15%">Contract</th>
                        <th width="20%">Amount Burned</th>
                        <th width="15%">Status</th>
                        <th width="20%">Tx Hash</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $host = 'localhost';
                    $db   = 'orionzer_orion';
                    $user = 'orionzer_manaz';
                    $pass = 'Alif@2003';

                    try {
                        $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
                        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                        $stmt = $pdo->query("SELECT * FROM burn_logs ORDER BY created_at DESC LIMIT 50");
                        
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            $hashShort = substr($row['tx_hash'], 0, 6) . '...' . substr($row['tx_hash'], -4);
                            $walletShort = substr($row['user_wallet'], 0, 6) . '...' . substr($row['user_wallet'], -4);
                            $contractShort = substr($row['contract_address'], 0, 6) . '...' . substr($row['contract_address'], -4);
                            
                            $timeObj = new DateTime($row['created_at']);
                            $dateFormatted = $timeObj->format('d M, H:i');
                            
                            echo "<tr>";
                            echo "<td><span class='font-mono'>" . $dateFormatted . "</span></td>";
                            echo "<td title='".$row['user_wallet']."'><span class='font-mono' style='color:#64748b'>" . $walletShort . "</span></td>";
                            echo "<td title='".$row['contract_address']."'><span class='font-mono'>" . $contractShort . "</span></td>";
                            
                            // Kolom Amount Burned (Warna Merah Api)
                            echo "<td><span class='amount' style='color:#ef4444;'>🔥 " . number_format($row['amount'], 2) . " " . $row['symbol'] . "</span></td>";
                            
                            echo "<td><span class='badge badge-success'>Success</span></td>";
                            echo "<td><a class='hash-link' href='https://explorer.paxinet.io/txs/" . $row['tx_hash'] . "' target='_blank'>$hashShort ↗</a></td>";
                            echo "</tr>";
                        }
                    } catch (PDOException $e) {
                        echo "<tr><td colspan='6' style='padding: 2rem; color: #ef4444; text-align:center;'>Error: " . $e->getMessage() . "</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>