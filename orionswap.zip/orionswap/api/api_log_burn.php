<?php
// File: api_log_burn.php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

// 1. Koneksi Database
$host = 'localhost';
$db   = 'orionzer_orion';
$user = 'orionzer_manaz';
$pass = 'Alif@2003';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'msg' => 'Database Connection Failed']);
    exit;
}

// 2. Ambil Data JSON dari JavaScript
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// 3. Validasi Input
if (!isset($data['tx_hash']) || empty($data['tx_hash'])) {
    echo json_encode(['status' => 'error', 'msg' => 'No Transaction Hash']);
    exit;
}

// 4. Simpan ke Tabel burn_logs
try {
    $stmt = $pdo->prepare("INSERT INTO burn_logs (user_wallet, tx_hash, contract_address, amount, symbol) VALUES (?, ?, ?, ?, ?)");
    
    $stmt->execute([
        $data['user_wallet'],
        $data['tx_hash'],
        $data['contract_address'],
        $data['amount'],
        $data['symbol']
    ]);

    echo json_encode(['status' => 'success', 'msg' => 'Burn logged successfully']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
}
?>