<?php
// api_log_swap.php
// Versi: Debugging Lengkap (Mencatat Error ke File Log Server)

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");

// --- AKTIFKAN LOGGING ---
// Ini akan membuat file bernama "error_log" di folder public_html/log/ script Anda
ini_set('log_errors', 1);
ini_set('error_log', dirname(__FILE__) . '/error_log'); 
error_reporting(E_ALL);

// --- KONFIGURASI DATABASE ---
$host = 'localhost';
$db   = 'orionzer_orion';
$user = 'orionzer_manaz';
$pass = 'Alif@2003';

// Fungsi helper untuk mempersingkat penulisan log
function catatLog($pesan) {
    $waktu = date("Y-m-d H:i:s");
    // Menggunakan error_log bawaan PHP
    error_log("[$waktu] ORION_SWAP_LOG: $pesan");
}

// 1. KONEKSI DATABASE
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Catat error detail ke log
    catatLog("CRITICAL: Gagal Koneksi Database -> " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode(['status' => 'error', 'msg' => 'Database Connection Failed']);
    exit;
}

// 2. TERIMA DATA & DEBUG
$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true);

// 3. VALIDASI INPUT
if (!isset($input['tx_hash'])) {
    $ip = $_SERVER['REMOTE_ADDR'];
    // Catat siapa yang akses & data apa yang dikirim (bantu debug jika JSON rusak)
    catatLog("WARNING: Akses tanpa TX Hash dari IP $ip. Raw Data: '$rawInput'");
    
    echo json_encode(['status' => 'error', 'msg' => 'No Transaction Hash']);
    exit;
}

// 4. SIMPAN KE DATABASE
try {
    $stmt = $pdo->prepare("INSERT INTO swap_logs (user_wallet, tx_hash, amount_in, token_from, amount_out, token_to) VALUES (?, ?, ?, ?, ?, ?)");
    
    $stmt->execute([
        $input['user_wallet'],
        $input['tx_hash'],
        $input['amount_in'],
        $input['token_from'],
        $input['amount_out'],
        $input['token_to']
    ]);

    // Sukses (Tidak perlu log jika sukses agar file log tidak penuh sampah)
    echo json_encode(['status' => 'success']);

} catch (PDOException $e) {
    // Error Duplikat (Wajar, abaikan log fatal)
    if ($e->getCode() == 23000) {
        echo json_encode(['status' => 'exists', 'msg' => 'Transaction already recorded']);
    } else {
        // Error SQL Lainnya (Misal: kolom salah, tipe data salah) -> WAJIB LOG
        catatLog("SQL ERROR: " . $e->getMessage() . " | Data: " . $rawInput);
        
        echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
    }
}
?>