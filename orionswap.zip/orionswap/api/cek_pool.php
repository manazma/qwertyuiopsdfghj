<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staking Monitor Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --bg-main: #09090b;
            --bg-card: #18181b;
            --border: #27272a;
            --text-main: #f4f4f5;
            --text-muted: #a1a1aa;
            --primary: #10b981;
            --warning: #fbbf24;
            --danger: #ef4444;
            --info: #3b82f6;
        }
        body {
            background-color: var(--bg-main);
            color: var(--text-main);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--border);
        }
        .header h1 { margin: 0; font-size: 24px; display: flex; align-items: center; gap: 10px; }
        .summary-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        .card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
            text-align: center;
        }
        .card-value { font-size: 28px; font-weight: bold; margin-bottom: 5px; color: var(--primary); }
        .card-label { font-size: 14px; color: var(--text-muted); }
        
        table {
            width: 100%;
            border-collapse: collapse;
            background: var(--bg-card);
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid var(--border);
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
        }
        th {
            background: #1f1f22;
            color: var(--text-muted);
            font-weight: 600;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 0.5px;
        }
        tr:hover { background: #27272a; }
        
        .badge {
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .badge-safe { background: rgba(16, 185, 129, 0.1); color: var(--primary); border: 1px solid var(--primary); }
        .badge-warning { background: rgba(251, 191, 36, 0.1); color: var(--warning); border: 1px solid var(--warning); }
        .badge-danger { background: rgba(239, 68, 68, 0.1); color: var(--danger); border: 1px solid var(--danger); }
        .badge-hot { background: rgba(239, 68, 68, 0.1); color: #ef4444; }
        .badge-cold { background: rgba(59, 130, 246, 0.1); color: #3b82f6; }
        .badge-vip { background: rgba(168, 85, 247, 0.1); color: #a855f7; border: 1px solid #a855f7; }
        
        .loading { text-align: center; padding: 50px; color: var(--text-muted); font-size: 18px; }
        .contract-addr { color: var(--text-muted); font-family: monospace; font-size: 12px; }
        
        .sub-text { font-size: 11px; color: var(--text-muted); margin-top: 4px; }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1><i class="bi bi-shield-lock"></i> Pool Monitor & Risk Analyzer</h1>
        <button onclick="location.reload()" style="padding: 8px 16px; background: var(--primary); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: bold;">
            <i class="bi bi-arrow-clockwise"></i> Refresh Data
        </button>
    </div>

    <div class="summary-cards">
        <div class="card">
            <div class="card-value" id="tot-pools">0</div>
            <div class="card-label">Total Active Pools</div>
        </div>
        <div class="card">
            <div class="card-value" id="tot-warning" style="color: var(--warning);">0</div>
            <div class="card-label">Pools with Deficit (Warning)</div>
        </div>
        <div class="card">
            <div class="card-value" id="tot-empty" style="color: var(--danger);">0</div>
            <div class="card-label">Empty Reward Pools</div>
        </div>
    </div>

    <div id="table-container">
        <div class="loading" id="loading-indicator">
            <i class="bi bi-arrow-repeat" style="animation: spin 1s linear infinite; display: inline-block;"></i> 
            Scanning blockchain for pools...
        </div>
        
        <table id="data-table" style="display: none;">
            <thead>
                <tr>
                    <th>Contract</th>
                    <th>Tokens (Stake / Earn)</th>
                    <th>Pool Config</th>
                    <th>TVL (Staked)</th>
                    <th>Current APY</th>
                    <th>1-Year Reward Need</th>
                    <th>Reward Pool Size</th>
                    <th>Health Status</th>
                </tr>
            </thead>
            <tbody id="table-body">
                </tbody>
        </table>
    </div>
</div>

<script>
const LCD = "https://mainnet-lcd.paxinet.io";
const CODE_ID = "22";
const DECIMALS = 6;

const tokenCache = {};
let warningCount = 0;
let emptyCount = 0;

const formatDec = (val) => (Number(val) / 10**DECIMALS).toLocaleString("en-US", {maximumFractionDigits: 2});
const rawToNum = (val) => Number(val) / 10**DECIMALS;

// Utility untuk konversi detik ke Hari/Jam
function formatDuration(sec) {
    if (!sec || isNaN(sec) || sec <= 0) return "No Lock";
    if (sec >= 86400) return (sec / 86400).toFixed(1) + " Days";
    if (sec >= 3600) return (sec / 3600).toFixed(1) + " Hours";
    if (sec >= 60) return (sec / 60).toFixed(1) + " Mins";
    return sec + " Secs";
}

// Get Token Info (Symbol)
async function getTokenInfo(tokenAddr) {
    if (!tokenAddr) return "UNK";
    if (tokenCache[tokenAddr]) return tokenCache[tokenAddr];
    
    // Deteksi Native Token
    if (!tokenAddr.startsWith("paxi1")) {
        let sym = tokenAddr === "upaxi" ? "PAXI" : (tokenAddr.startsWith("factory/") ? tokenAddr.split("/").pop().toUpperCase() : tokenAddr.substring(0,5).toUpperCase());
        tokenCache[tokenAddr] = sym;
        return sym;
    }
    
    // Deteksi CW20 Smart Contract
    try {
        const q = btoa(JSON.stringify({ token_info: {} }));
        const info = await fetch(`${LCD}/cosmwasm/wasm/v1/contract/${tokenAddr}/smart/${q}`).then(r => r.json());
        tokenCache[tokenAddr] = info.data.symbol;
        return info.data.symbol;
    } catch(e) { return "UNK"; }
}

async function scanPools() {
    const tbody = document.getElementById('table-body');
    try {
        // Tarik semua contract address
        const res = await fetch(`${LCD}/cosmwasm/wasm/v1/code/${CODE_ID}/contracts?pagination.limit=1000`).then(r => r.json());
        const contracts = res.contracts || [];
        
        document.getElementById('tot-pools').innerText = contracts.length;
        document.getElementById('loading-indicator').style.display = 'none';
        document.getElementById('data-table').style.display = 'table';

        for (let contractAddr of contracts) {
            try {
                // 1. Get Pool Status (Membaca semua data konfigurasi lengkap dari SC)
                const qStatus = btoa(JSON.stringify({ get_status: {} }));
                const statusRes = await fetch(`${LCD}/cosmwasm/wasm/v1/contract/${contractAddr}/smart/${qStatus}`).then(r => r.json());
                const status = statusRes.data;

                // 2. Get Symbols (Menampilkan nama koin)
                const stakeSym = await getTokenInfo(status.staking_token);
                const rewardSym = await getTokenInfo(status.reward_token);

                // 3. Ambil data nilai saldo
                const tvlNum = rawToNum(status.total_staked || "0");
                const apyNum = Number(status.current_apy || 0);
                const poolRewardSize = rawToNum(status.reward_pool_size || "0");
                
                // 4. Hitung Kebutuhan Reward selama 1 Tahun = TVL * (APY / 100)
                const needFor1Year = tvlNum * (apyNum / 100);
                
                // 5. Setup Parameter Config (Lock, VIP, Dynamic APY)
                const lockTime = formatDuration(status.lock_duration);
                const isDynamic = status.is_dynamic;
                const dynamicText = isDynamic ? `Dynamic (${status.apy_min}% - ${status.apy_max}%)` : `Fixed APY`;
                const vipBadge = status.vip_status === "Enabled" ? `<span class="badge badge-vip">VIP Only</span>` : `<span class="badge" style="background:#27272a; color:#a1a1aa;">Public</span>`;

                // 6. Tentukan Status/Badge Health
                let statusBadge = '';
                if (poolRewardSize === 0) {
                    statusBadge = `<span class="badge badge-danger"><i class="bi bi-x-octagon-fill"></i> Empty Pool</span>`;
                    emptyCount++;
                } else if (poolRewardSize < needFor1Year) {
                    statusBadge = `<span class="badge badge-warning"><i class="bi bi-exclamation-triangle-fill"></i> Deficit 1-Year</span>`;
                    warningCount++;
                } else {
                    statusBadge = `<span class="badge badge-safe"><i class="bi bi-check-circle-fill"></i> Safe</span>`;
                }

                let apyBadge = `${apyNum}%`;
                if (apyNum >= 1000) apyBadge += ` <span class="badge badge-hot" title="High APY">🔥</span>`;
                else if (apyNum <= 10) apyBadge += ` <span class="badge badge-cold" title="Low APY">📉</span>`;

                // Render Baris ke Tabel
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>
                        <div>${contractAddr.slice(0,8)}...${contractAddr.slice(-6)}</div>
                        <div class="contract-addr" style="font-size:10px; cursor:pointer; color:var(--primary);" onclick="navigator.clipboard.writeText('${contractAddr}')">Copy Address</div>
                    </td>
                    <td>
                        <div><b>${stakeSym}</b> <i class="bi bi-arrow-right" style="color:var(--text-muted); margin:0 4px;"></i> <b>${rewardSym}</b></div>
                    </td>
                    <td>
                        <div style="font-size:12px;">
                            <div><i class="bi bi-clock"></i> <b>${lockTime}</b></div>
                            <div class="sub-text">${dynamicText}</div>
                            <div style="margin-top:4px;">${vipBadge}</div>
                        </div>
                    </td>
                    <td>${tvlNum.toLocaleString("en-US", {maximumFractionDigits: 2})} ${stakeSym}</td>
                    <td>
                        <div style="font-size: 16px; font-weight: bold;">${apyBadge}</div>
                    </td>
                    <td>
                        <div style="color:var(--warning); font-weight:bold;">${needFor1Year.toLocaleString("en-US", {maximumFractionDigits: 2})}</div>
                        <div class="sub-text">${rewardSym} needed</div>
                    </td>
                    <td>
                        <div style="color:var(--primary); font-weight:bold; font-size:16px;">
                            <i class="bi bi-wallet2"></i> ${poolRewardSize.toLocaleString("en-US", {maximumFractionDigits: 2})}
                        </div>
                        <div class="sub-text">${rewardSym} left in pool</div>
                    </td>
                    <td>${statusBadge}</td>
                `;
                tbody.appendChild(tr);

                // Update Angka di Kartu Atas
                document.getElementById('tot-warning').innerText = warningCount;
                document.getElementById('tot-empty').innerText = emptyCount;

                // Jeda 200ms untuk mencegah Rate Limit dari RPC server
                await new Promise(resolve => setTimeout(resolve, 200));

            } catch(err) {
                console.error("Error processing", contractAddr, err);
            }
        }
    } catch(err) {
        document.getElementById('loading-indicator').innerHTML = `<span style="color:var(--danger)">Error fetching contracts from blockchain.</span>`;
    }
}

// Start scanning on load
window.onload = scanPools;
</script>
</body>
</html>